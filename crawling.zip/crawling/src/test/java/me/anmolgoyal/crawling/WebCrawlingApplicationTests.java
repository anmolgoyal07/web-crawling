package me.anmolgoyal.crawling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebCrawlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
